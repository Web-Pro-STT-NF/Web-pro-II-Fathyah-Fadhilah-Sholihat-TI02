<?php
include_once 'atas.php';
?>
<H1>Selamat Datang</H1>

<?php
include_once 'bawah.php';
?>
